#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class HcalDetector+;
#pragma link C++ class HcalApparatus+;
#pragma link C++ class FbusDetector+;
#pragma link C++ class FbusApparatus+;
#pragma link C++ class CdetDetector+;
#pragma link C++ class CdetApparatus+;

#endif
