#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class UserDetector+;
#pragma link C++ class UserScintillator+;
#pragma link C++ class UserApparatus+;
#pragma link C++ class UserModule+;
#pragma link C++ class UserEvtHandler+;

#endif
